//
//  DetailViewController.swift
//  MyStory
//
//  Created by alfredo cabanas on 3/21/23.
//

import UIKit

class DetailViewController: UIViewController {

    // Property
    var descriptionn: descriptionn?
    
    @IBOutlet weak var detailImage: UIImageView!
    
    @IBOutlet weak var tittleLabel: UILabel!
    
    
    @IBOutlet weak var descriptionLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let descriptionn = descriptionn {
            print(descriptionn.name)
            detailImage.image = descriptionn.image
            tittleLabel.text = descriptionn.name
            descriptionLabel.text = descriptionn.body
        }
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
