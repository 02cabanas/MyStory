//
//  descriptionn.swift
//  MyStory
//
//  Created by alfredo cabanas on 3/21/23.
//
import UIKit

// This struct will model the properties for a Dinosaur
struct descriptionn {
    let name: String
    let body: String
    let image: UIImage
}
