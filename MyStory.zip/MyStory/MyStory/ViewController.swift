//
//  ViewController.swift
//  MyStory
//
//  Created by alfredo cabanas on 3/21/23.
//

import UIKit

class ViewController: UIViewController {

    let backstory = descriptionn(name: "backstory", body: "Satoru Gojo (五ご条じょう悟さとる Gojō Satoru?) is one of the main protagonists of the Jujutsu Kaisen series. He is a special grade jujutsu sorcerer and widely recognized as the strongest in the world. Satoru is the pride of the Gojo Family, the first person to inherit both the Limitless and the Six Eyes in four hundred years. He works as a teacher at the Tokyo Jujutsu High and uses his influence to protect and train strong young allies.", image: UIImage(named: "backstory")!)
    let weakness = descriptionn(name: "weakness", body: "As the most powerful Jujutsu sorcerer in the world, Gojo doesn’t really have any specific weaknesses. He has been defeated with the Inverted Spear of Heaven, a very powerful cursed tool, but that was a long time ago; the Black Rope also seems like it can harm him, but it’s not something that can really defeat him, according to what we know from Jujutsu Kaisen 0. The Domain Amplification technique was also used to harm him in Shibuya, but Gojo managed to find a weak spot in it and survive. Ultimately, he has been sealed away, but the seal is a really OP technique so we don’t really count it as his character-specific weakness.", image: UIImage(named: "weakness")!)
    let strength = descriptionn(name: "Strength", body: "Being the strongest character in the story, Satoru Gojo serves as the benchmark for viewers to know what’s possible in the world of Jujutsu Kaisen, what level of strength the characters possess or how strong or weak a character is. At the start of the story, Gojo was already at his absolute prime. He has very sharp reflexes, he’s a genius and a bright tactician. When it comes to cursed energy and physical strength, he is just the ceiling of power in Jujutsu Kaisen. Gojo has many abilities, but what makes him very special is that he was blessed with two inherent abilities which are domain expansion and infinite void, which will be explained below. The extent of Gojo’s powers is unknown but the fact that a drop of rain wouldn’t be able to touch him without his permission says a lot about his powers.", image: UIImage(named: "strength")!)

    // Array for storing Dinosaurs
    var descriptionss: [descriptionn] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        descriptionss = [backstory, weakness, strength]
        
        
    }
    

    
    @IBAction func backstorytap1(_ sender: UITapGestureRecognizer) {
        if let tappedView = sender.view {
            performSegue(withIdentifier: "detailSegue", sender: tappedView)
        }
    }
    
    
    @IBAction func weaknestap1(_ sender: UITapGestureRecognizer) {
        if let tappedView = sender.view {
            performSegue(withIdentifier: "detailSegue", sender: tappedView)
        }
    }
    
    
    @IBAction func strengthtap1(_ sender: UITapGestureRecognizer) {
        if let tappedView = sender.view {
            performSegue(withIdentifier: "detailSegue", sender: tappedView)
        }
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        if segue.identifier == "detailSegue",
            let tappedView = sender as? UIView,
            let detailViewController = segue.destination as? DetailViewController {

            if tappedView.tag == 0 {
                detailViewController.descriptionn = descriptionss[0]
            } else if tappedView.tag == 1 {
                detailViewController.descriptionn = descriptionss[1]
            } else if tappedView.tag == 2 {
                detailViewController.descriptionn = descriptionss[2]
            } else {
                print("no option was tapped check selection")
            }
        }
    }
    


}

